module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/src/hooks/Axios.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// config/api.js
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
;
const API_BASE_URL = ("TURBOPACK compile-time value", "https://wewon-backend.vercel.app/") || 'http://localhost:4000';
// Create axios instance with default config
const apiClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});
// Request interceptor to add auth token
apiClient.interceptors.request.use((config)=>{
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error)=>{
    return Promise.reject(error);
});
const __TURBOPACK__default__export__ = apiClient;
}),
"[project]/src/store/auth/authThunk.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchUserProfile",
    ()=>fetchUserProfile,
    "loginUser",
    ()=>loginUser,
    "signupUser",
    ()=>signupUser,
    "updateStudentProfile",
    ()=>updateStudentProfile,
    "updateUserProfile",
    ()=>updateUserProfile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/Axios.jsx [app-ssr] (ecmascript)");
;
;
const loginUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("auth/loginUser", async (credentials, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/auth/login", credentials);
        const token = res?.data?.token;
        if (token) {
            localStorage.setItem("token", token);
        }
        return res.data; // expecting { user, token }
    } catch (err) {
        return rejectWithValue(err.response?.data?.message || "Login failed");
    }
});
const signupUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("auth/signupUser", async (credentials, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/auth/signup", credentials);
        return res.data;
    } catch (err) {
        return rejectWithValue(err.response?.data?.message || "Signup failed");
    }
});
const fetchUserProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("auth/fetchUserProfile", async (_, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/profile");
        return res.data.profile;
    } catch (err) {
        // Handle 401 - Invalid or expired token
        if (err.response?.status === 401) {
            localStorage.removeItem("token");
        }
        return rejectWithValue(err.response?.data?.message || "Failed to fetch user");
    }
});
const updateUserProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("auth/updateUserProfile", async (data, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put("/api/profile/basic", data);
        return res.data.user;
    } catch (err) {
        return rejectWithValue(err.response?.data?.message || "Failed to update user profile");
    }
});
const updateStudentProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("profile/updateStudentProfile", async (data, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put("/api/profile", data);
        return res.data.profile;
    } catch (err) {
        const msg = err.response?.data?.message || "Failed to update profile";
        return rejectWithValue(msg);
    }
});
}),
"[project]/src/store/auth/authSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "logout",
    ()=>logout,
    "selectAuth",
    ()=>selectAuth,
    "selectAuthLoading",
    ()=>selectAuthLoading,
    "selectIsAuthenticated",
    ()=>selectIsAuthenticated,
    "selectUser",
    ()=>selectUser,
    "setCredentials",
    ()=>setCredentials,
    "setLoadingFalse",
    ()=>setLoadingFalse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/auth/authThunk.ts [app-ssr] (ecmascript)");
;
;
// ---------------------------
// Initial State
// ---------------------------
const initialState = {
    user: {
        _id: "",
        userId: {
            _id: "",
            name: "",
            email: "",
            role: "",
            avatar: "",
            phone: ""
        },
        preferences: {
            preferredStates: [],
            preferredCollegeType: "any"
        },
        savedColleges: [],
        appliedColleges: [],
        exams: [],
        createdAt: "",
        updatedAt: ""
    },
    token: null,
    loading: true,
    btnloading: false,
    error: null,
    isAuthenticated: false
};
// ---------------------------
// Slice
// ---------------------------
const authSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "auth",
    initialState,
    reducers: {
        logout: (state)=>{
            state.user = {
                preferences: {
                    preferredStates: [],
                    preferredCollegeType: "any"
                },
                _id: "",
                userId: {
                    _id: "",
                    name: "",
                    email: "",
                    role: "",
                    avatar: "",
                    phone: ""
                },
                savedColleges: [],
                appliedColleges: [],
                exams: [],
                createdAt: "",
                updatedAt: ""
            };
            state.token = null;
            state.isAuthenticated = false;
            state.error = null;
            state.loading = false;
            window.location.href = "/auth";
            localStorage.removeItem("token");
        },
        setCredentials: (state, action)=>{
            state.user = action.payload.user;
            state.token = action.payload.token;
            state.isAuthenticated = true;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        },
        setLoadingFalse: (state)=>{
            state.loading = false;
        }
    },
    extraReducers: (builder)=>{
        // Login
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loginUser"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loginUser"].fulfilled, (state, action)=>{
            state.loading = false;
            state.user.userId = action.payload.user;
            state.token = action.payload.token;
            state.isAuthenticated = true;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loginUser"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Login failed";
        });
        // Signup
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signupUser"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signupUser"].fulfilled, (state, action)=>{
            state.loading = false;
            state.user = action.payload.user;
            state.token = action.payload.token;
            state.isAuthenticated = true;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signupUser"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Signup failed";
        });
        // Fetch User
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserProfile"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserProfile"].fulfilled, (state, action)=>{
            state.loading = false;
            state.user = action.payload;
            state.isAuthenticated = true;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserProfile"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Fetch failed";
            state.isAuthenticated = false;
        });
        // Update User
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateUserProfile"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateUserProfile"].fulfilled, (state, action)=>{
            state.loading = false;
            state.user.userId = {
                ...action.payload
            };
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateUserProfile"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Profile update failed";
        });
        // UPDATE STUDENT PROFILE
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateStudentProfile"].pending, (state)=>{
            state.btnloading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateStudentProfile"].fulfilled, (state, action)=>{
            state.btnloading = false;
            if (state.user) {
                state.user = {
                    ...state.user,
                    ...action.payload
                };
            }
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateStudentProfile"].rejected, (state, action)=>{
            state.btnloading = false;
            state.error = action.payload || "Profile update failed.";
        });
    }
});
const { logout, setCredentials, setLoadingFalse } = authSlice.actions;
const __TURBOPACK__default__export__ = authSlice.reducer;
const selectAuth = (state)=>state.auth;
const selectUser = (state)=>state.auth.user;
const selectIsAuthenticated = (state)=>state.auth.isAuthenticated;
const selectAuthLoading = (state)=>state.auth.loading;
}),
"[project]/src/store/counsellor/counsellorThunk.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchUserProfile",
    ()=>fetchUserProfile,
    "loginUser",
    ()=>loginUser,
    "signupUser",
    ()=>signupUser,
    "updateCounsellorProfile",
    ()=>updateCounsellorProfile,
    "updateUserProfile",
    ()=>updateUserProfile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/Axios.jsx [app-ssr] (ecmascript)");
;
;
const loginUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("auth/loginUser", async (credentials, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/auth/login", credentials);
        const token = res?.data?.token;
        if (token) {
            localStorage.setItem("token", token);
        }
        return res.data; // expecting { user, token }
    } catch (err) {
        return rejectWithValue(err.response?.data?.message || "Login failed");
    }
});
const signupUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("auth/signupUser", async (credentials, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/auth/signup", credentials);
        return res.data;
    } catch (err) {
        return rejectWithValue(err.response?.data?.message || "Signup failed");
    }
});
const fetchUserProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("auth/fetchUserProfile", async (_, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/profile");
        return res.data.profile;
    } catch (err) {
        return rejectWithValue(err.response?.data?.message || "Failed to fetch user");
    }
});
const updateUserProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("auth/updateUserProfile", async (data, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put("/api/profile/basic", data);
        return res.data.user;
    } catch (err) {
        return rejectWithValue(err.response?.data?.message || "Failed to update user profile");
    }
});
const updateCounsellorProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("profile/updateCounsellorProfile", async (data, { rejectWithValue })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put("/api/profile", data);
        console.log({
            res
        });
        return res.data.updatedProfile;
    } catch (err) {
        const msg = err.response?.data?.message || "Failed to update profile";
        return rejectWithValue(msg);
    }
});
}),
"[project]/src/store/counsellor/counsellorSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "logout",
    ()=>logout,
    "selectAuth",
    ()=>selectAuth,
    "selectAuthLoading",
    ()=>selectAuthLoading,
    "selectIsAuthenticated",
    ()=>selectIsAuthenticated,
    "selectUser",
    ()=>selectUser,
    "setCredentials",
    ()=>setCredentials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/counsellor/counsellorThunk.ts [app-ssr] (ecmascript)");
;
;
// ---------------------------
// Initial State
// ---------------------------
const initialState = {
    user: {
        _id: "",
        userId: {
            _id: "",
            name: "",
            email: "",
            role: "",
            avatar: "",
            phone: ""
        },
        preferences: {
            preferredStates: [],
            preferredCollegeType: "any"
        },
        savedColleges: [],
        appliedColleges: [],
        exams: [],
        createdAt: "",
        updatedAt: ""
    },
    token: null,
    loading: true,
    btnloading: false,
    error: null,
    isAuthenticated: false
};
// ---------------------------
// Slice
// ---------------------------
const counselloSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "counsello",
    initialState,
    reducers: {
        logout: (state)=>{
            state.user = {
                preferences: {
                    preferredStates: [],
                    preferredCollegeType: "any"
                },
                _id: "",
                userId: {
                    _id: "",
                    name: "",
                    email: "",
                    role: "",
                    avatar: "",
                    phone: ""
                },
                savedColleges: [],
                appliedColleges: [],
                exams: [],
                createdAt: "",
                updatedAt: ""
            };
            state.token = null;
            state.isAuthenticated = false;
            state.error = null;
            window.location.href = "/auth";
            localStorage.removeItem("token");
        },
        setCredentials: (state, action)=>{
            state.user = action.payload.user;
            state.token = action.payload.token;
            state.isAuthenticated = true;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }
    },
    extraReducers: (builder)=>{
        // Login
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loginUser"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loginUser"].fulfilled, (state, action)=>{
            state.loading = false;
            state.user.userId = action.payload.user;
            state.token = action.payload.token;
            state.isAuthenticated = true;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loginUser"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Login failed";
        });
        // Signup
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signupUser"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signupUser"].fulfilled, (state, action)=>{
            state.loading = false;
            state.user = action.payload.user;
            state.token = action.payload.token;
            state.isAuthenticated = true;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signupUser"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Signup failed";
        });
        // Fetch User
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserProfile"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserProfile"].fulfilled, (state, action)=>{
            state.loading = false;
            state.user = action.payload;
            state.isAuthenticated = true;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserProfile"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Fetch failed";
            state.isAuthenticated = false;
        });
        // Update User
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateUserProfile"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateUserProfile"].fulfilled, (state, action)=>{
            state.loading = false;
            state.user.userId = {
                ...action.payload
            };
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateUserProfile"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Profile update failed";
        });
        // UPDATE STUDENT PROFILE
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateCounsellorProfile"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateCounsellorProfile"].fulfilled, (state, action)=>{
            state.loading = false;
            if (state.user) {
                const { userId, ...rest } = action.payload;
                state.user = {
                    ...state.user,
                    ...rest
                };
            }
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateCounsellorProfile"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Profile update failed.";
        });
    }
});
const { logout, setCredentials } = counselloSlice.actions;
const __TURBOPACK__default__export__ = counselloSlice.reducer;
const selectAuth = (state)=>state.counsellor;
const selectUser = (state)=>state.counsellor.user;
const selectIsAuthenticated = (state)=>state.counsellor.isAuthenticated;
const selectAuthLoading = (state)=>state.counsellor.loading;
}),
"[project]/src/store/college/collegeThunk.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchCollegeById",
    ()=>fetchCollegeById,
    "fetchCollegeBySlug",
    ()=>fetchCollegeBySlug,
    "fetchCollegeDetails",
    ()=>fetchCollegeDetails,
    "fetchColleges",
    ()=>fetchColleges,
    "fetchNearbyColleges",
    ()=>fetchNearbyColleges,
    "fetchRecommendedColleges",
    ()=>fetchRecommendedColleges,
    "fetchSimilarColleges",
    ()=>fetchSimilarColleges
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/Axios.jsx [app-ssr] (ecmascript)");
;
;
const fetchColleges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("college/fetchColleges", async (params = {}, { rejectWithValue })=>{
    try {
        const { page = 1, limit = 10, searchQuery = "", instituteTypes = [], cities = [] } = params;
        // Build query parameters
        const queryParams = new URLSearchParams({
            page: page.toString(),
            limit: limit.toString()
        });
        if (searchQuery) {
            queryParams.append("search", searchQuery);
        }
        // Add institute type filter (API expects 'Type')
        // Append each type as a separate query param for multiple selections
        if (instituteTypes.length > 0) {
            instituteTypes.forEach((type)=>{
                queryParams.append("type", type);
            });
        }
        // Add city filter
        if (cities.length > 0) {
            cities.forEach((city)=>{
                queryParams.append("city", city);
            });
        }
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/colleges?${queryParams.toString()}`);
        return {
            data: response.data.data,
            totalPages: response.data.totalPages,
            currentPage: response.data.currentPage,
            totalColleges: response.data.totalColleges
        };
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch colleges");
    }
});
const fetchRecommendedColleges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("college/fetchRecommendedColleges", async (limit = 4, { rejectWithValue })=>{
    try {
        const queryParams = new URLSearchParams({
            isRecommended: "true",
            limit: limit.toString(),
            page: "1"
        });
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/colleges?${queryParams.toString()}`);
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch recommended colleges");
    }
});
const fetchNearbyColleges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("college/fetchNearbyColleges", async (collegeId, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/colleges/nearby/${collegeId}`);
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "Failed to fetch nearby colleges");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch nearby colleges");
    }
});
const fetchSimilarColleges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("college/fetchSimilarColleges", async (collegeId, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/colleges/similar/${collegeId}`);
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "Failed to fetch similar colleges");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch similar colleges");
    }
});
const fetchCollegeById = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("college/fetchCollegeById", async (id, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/colleges/${id}`);
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "College not found");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch college");
    }
});
const fetchCollegeBySlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("college/fetchCollegeBySlug", async (slug, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/colleges/slug/${slug}`);
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "College not found");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch college");
    }
});
const fetchCollegeDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("college/fetchCollegeDetails", async (instituteId, { rejectWithValue })=>{
    try {
        const detailTypes = [
            "admission-rules",
            "connectivity",
            "courses",
            "facilities",
            "fees",
            "fee-waivers",
            "placements",
            "rankings",
            "seat-matrix",
            "social-media"
        ];
        // Fetch all detail types in parallel
        const promises = detailTypes.map((type)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/colleges/${instituteId}/${type}`).then((res)=>({
                    type,
                    data: res.data.data
                })).catch(()=>({
                    type,
                    data: []
                })));
        const results = await Promise.all(promises);
        // Transform results into CollegeDetails object
        const collegeDetails = {
            admissionRules: [],
            connectivity: [],
            courses: [],
            facilities: [],
            fees: [],
            feeWaivers: [],
            placements: [],
            rankings: [],
            seatMatrix: [],
            socialMedia: []
        };
        results.forEach((result)=>{
            switch(result.type){
                case "admission-rules":
                    collegeDetails.admissionRules = result.data;
                    break;
                case "connectivity":
                    collegeDetails.connectivity = result.data;
                    break;
                case "courses":
                    collegeDetails.courses = result.data;
                    break;
                case "facilities":
                    collegeDetails.facilities = result.data;
                    break;
                case "fees":
                    collegeDetails.fees = result.data;
                    break;
                case "fee-waivers":
                    collegeDetails.feeWaivers = result.data;
                    break;
                case "placements":
                    collegeDetails.placements = result.data;
                    break;
                case "rankings":
                    collegeDetails.rankings = result.data;
                    break;
                case "seat-matrix":
                    collegeDetails.seatMatrix = result.data;
                    break;
                case "social-media":
                    collegeDetails.socialMedia = result.data;
                    break;
            }
        });
        return collegeDetails;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch college details");
    }
}); // Keep existing auth thunks - they should be imported from auth folder if needed
 // export { loginUser, signupUser, fetchUserProfile, updateUserProfile, updateCounsellorProfile } from "../auth/authThunk";
}),
"[project]/src/store/college/collegeSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearCollegeDetails",
    ()=>clearCollegeDetails,
    "default",
    ()=>__TURBOPACK__default__export__,
    "resetColleges",
    ()=>resetColleges,
    "selectCollegeDetails",
    ()=>selectCollegeDetails,
    "selectCollegeDetailsError",
    ()=>selectCollegeDetailsError,
    "selectCollegeDetailsLoading",
    ()=>selectCollegeDetailsLoading,
    "selectColleges",
    ()=>selectColleges,
    "selectCollegesError",
    ()=>selectCollegesError,
    "selectCollegesLoading",
    ()=>selectCollegesLoading,
    "selectCurrentPage",
    ()=>selectCurrentPage,
    "selectNearbyColleges",
    ()=>selectNearbyColleges,
    "selectNearbyError",
    ()=>selectNearbyError,
    "selectNearbyLoading",
    ()=>selectNearbyLoading,
    "selectRecommendedColleges",
    ()=>selectRecommendedColleges,
    "selectRecommendedError",
    ()=>selectRecommendedError,
    "selectRecommendedLoading",
    ()=>selectRecommendedLoading,
    "selectSelectedCollege",
    ()=>selectSelectedCollege,
    "selectSimilarColleges",
    ()=>selectSimilarColleges,
    "selectSimilarError",
    ()=>selectSimilarError,
    "selectSimilarLoading",
    ()=>selectSimilarLoading,
    "selectTotalColleges",
    ()=>selectTotalColleges,
    "selectTotalPages",
    ()=>selectTotalPages
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/college/collegeThunk.ts [app-ssr] (ecmascript)");
;
;
// ---------------------------
// Initial State
// ---------------------------
const initialState = {
    colleges: [],
    totalPages: 0,
    currentPage: 1,
    totalColleges: 0,
    collegesLoading: false,
    collegesError: null,
    // Single college details
    selectedCollege: null,
    collegeDetails: null,
    collegeDetailsLoading: false,
    collegeDetailsError: null,
    // Recommended colleges
    recommendedColleges: [],
    recommendedLoading: false,
    recommendedError: null,
    // Nearby colleges
    nearbyColleges: [],
    nearbyLoading: false,
    nearbyError: null,
    // Similar colleges
    similarColleges: [],
    similarLoading: false,
    similarError: null
};
// ---------------------------
// Slice
// ---------------------------
const collegeSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "college",
    initialState,
    reducers: {
        resetColleges: (state)=>{
            state.colleges = [];
            state.totalPages = 0;
            state.currentPage = 1;
            state.totalColleges = 0;
            state.collegesError = null;
        },
        clearCollegeDetails: (state)=>{
            state.selectedCollege = null;
            state.collegeDetails = null;
            state.collegeDetailsError = null;
            state.nearbyColleges = [];
            state.similarColleges = [];
        }
    },
    extraReducers: (builder)=>{
        // Fetch Colleges
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchColleges"].pending, (state)=>{
            state.collegesLoading = true;
            state.collegesError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchColleges"].fulfilled, (state, action)=>{
            state.collegesLoading = false;
            state.colleges = action.payload.data;
            state.totalPages = action.payload.totalPages;
            state.currentPage = action.payload.currentPage;
            state.totalColleges = action.payload.totalColleges;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchColleges"].rejected, (state, action)=>{
            state.collegesLoading = false;
            state.collegesError = action.payload || "Failed to fetch colleges";
        });
        // Fetch College By ID
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeById"].pending, (state)=>{
            state.collegeDetailsLoading = true;
            state.collegeDetailsError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeById"].fulfilled, (state, action)=>{
            state.selectedCollege = action.payload;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeById"].rejected, (state, action)=>{
            state.collegeDetailsLoading = false;
            state.collegeDetailsError = action.payload || "Failed to fetch college";
        });
        // Fetch College By Slug
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeBySlug"].pending, (state)=>{
            state.collegeDetailsLoading = true;
            state.collegeDetailsError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeBySlug"].fulfilled, (state, action)=>{
            state.selectedCollege = action.payload;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeBySlug"].rejected, (state, action)=>{
            state.collegeDetailsLoading = false;
            state.collegeDetailsError = action.payload || "Failed to fetch college";
        });
        // Fetch College Details
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeDetails"].pending, (state)=>{
            state.collegeDetailsLoading = true;
            state.collegeDetailsError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeDetails"].fulfilled, (state, action)=>{
            state.collegeDetailsLoading = false;
            state.collegeDetails = action.payload;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCollegeDetails"].rejected, (state, action)=>{
            state.collegeDetailsLoading = false;
            state.collegeDetailsError = action.payload || "Failed to fetch college details";
        });
        // Fetch Recommended Colleges
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchRecommendedColleges"].pending, (state)=>{
            state.recommendedLoading = true;
            state.recommendedError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchRecommendedColleges"].fulfilled, (state, action)=>{
            state.recommendedLoading = false;
            state.recommendedColleges = action.payload;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchRecommendedColleges"].rejected, (state, action)=>{
            state.recommendedLoading = false;
            state.recommendedError = action.payload || "Failed to fetch recommended colleges";
        });
        // Fetch Nearby Colleges
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchNearbyColleges"].pending, (state)=>{
            state.nearbyLoading = true;
            state.nearbyError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchNearbyColleges"].fulfilled, (state, action)=>{
            state.nearbyLoading = false;
            state.nearbyColleges = action.payload;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchNearbyColleges"].rejected, (state, action)=>{
            state.nearbyLoading = false;
            state.nearbyError = action.payload || "Failed to fetch nearby colleges";
        });
        // Fetch Similar Colleges
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchSimilarColleges"].pending, (state)=>{
            state.similarLoading = true;
            state.similarError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchSimilarColleges"].fulfilled, (state, action)=>{
            state.similarLoading = false;
            state.similarColleges = action.payload;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchSimilarColleges"].rejected, (state, action)=>{
            state.similarLoading = false;
            state.similarError = action.payload || "Failed to fetch similar colleges";
        });
    }
});
const { resetColleges, clearCollegeDetails } = collegeSlice.actions;
const __TURBOPACK__default__export__ = collegeSlice.reducer;
const selectColleges = (state)=>state.college.colleges;
const selectCollegesLoading = (state)=>state.college.collegesLoading;
const selectCollegesError = (state)=>state.college.collegesError;
const selectTotalPages = (state)=>state.college.totalPages;
const selectCurrentPage = (state)=>state.college.currentPage;
const selectTotalColleges = (state)=>state.college.totalColleges;
const selectSelectedCollege = (state)=>state.college.selectedCollege;
const selectCollegeDetails = (state)=>state.college.collegeDetails;
const selectCollegeDetailsLoading = (state)=>state.college.collegeDetailsLoading;
const selectCollegeDetailsError = (state)=>state.college.collegeDetailsError;
const selectRecommendedColleges = (state)=>state.college.recommendedColleges;
const selectRecommendedLoading = (state)=>state.college.recommendedLoading;
const selectRecommendedError = (state)=>state.college.recommendedError;
const selectNearbyColleges = (state)=>state.college.nearbyColleges;
const selectNearbyLoading = (state)=>state.college.nearbyLoading;
const selectNearbyError = (state)=>state.college.nearbyError;
const selectSimilarColleges = (state)=>state.college.similarColleges;
const selectSimilarLoading = (state)=>state.college.similarLoading;
const selectSimilarError = (state)=>state.college.similarError;
}),
"[project]/src/store/counseling/counselingThunk.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchCounselingProductBySlug",
    ()=>fetchCounselingProductBySlug,
    "fetchCounselingProducts",
    ()=>fetchCounselingProducts,
    "toggleLikeProduct",
    ()=>toggleLikeProduct
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/Axios.jsx [app-ssr] (ecmascript)");
;
;
const fetchCounselingProducts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("counseling/fetchProducts", async (params = {}, { rejectWithValue })=>{
    try {
        const { page = 1, limit = 10 } = params;
        // Build query parameters
        const queryParams = new URLSearchParams({
            page: page.toString(),
            limit: limit.toString()
        });
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/counselling?${queryParams.toString()}`);
        return {
            data: response.data.data,
            total: response.data.total,
            count: response.data.count,
            currentPage: page,
            totalPages: Math.ceil(response.data.total / limit)
        };
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch counseling products");
    }
});
const fetchCounselingProductBySlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("counseling/fetchProductBySlug", async (slug, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/admin/products/slug/${slug}`);
        if (!response.data.success) {
            return rejectWithValue("Product not found");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch counseling product");
    }
});
const toggleLikeProduct = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("counseling/toggleLike", async (productId, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post(`/api/counselling/${productId}/like`);
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "Failed to toggle like");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to toggle like");
    }
});
}),
"[project]/src/store/counseling/counselingSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearSelectedProduct",
    ()=>clearSelectedProduct,
    "default",
    ()=>__TURBOPACK__default__export__,
    "resetProducts",
    ()=>resetProducts,
    "selectCounselingProducts",
    ()=>selectCounselingProducts,
    "selectCurrentPage",
    ()=>selectCurrentPage,
    "selectProductsError",
    ()=>selectProductsError,
    "selectProductsLoading",
    ()=>selectProductsLoading,
    "selectSelectedProduct",
    ()=>selectSelectedProduct,
    "selectSelectedProductError",
    ()=>selectSelectedProductError,
    "selectSelectedProductLoading",
    ()=>selectSelectedProductLoading,
    "selectTotal",
    ()=>selectTotal,
    "selectTotalPages",
    ()=>selectTotalPages
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/counseling/counselingThunk.ts [app-ssr] (ecmascript)");
;
;
// ---------------------------
// Initial State
// ---------------------------
const initialState = {
    products: [],
    totalPages: 0,
    currentPage: 1,
    total: 0,
    productsLoading: false,
    productsError: null,
    selectedProduct: null,
    selectedProductLoading: false,
    selectedProductError: null
};
// ---------------------------
// Slice
// ---------------------------
const counselingSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "counseling",
    initialState,
    reducers: {
        resetProducts: (state)=>{
            state.products = [];
            state.totalPages = 0;
            state.currentPage = 1;
            state.total = 0;
            state.productsError = null;
        },
        clearSelectedProduct: (state)=>{
            state.selectedProduct = null;
            state.selectedProductError = null;
        }
    },
    extraReducers: (builder)=>{
        // Fetch Counseling Products
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCounselingProducts"].pending, (state)=>{
            state.productsLoading = true;
            state.productsError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCounselingProducts"].fulfilled, (state, action)=>{
            state.productsLoading = false;
            state.products = action.payload.data;
            state.totalPages = action.payload.totalPages;
            state.currentPage = action.payload.currentPage;
            state.total = action.payload.total;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCounselingProducts"].rejected, (state, action)=>{
            state.productsLoading = false;
            state.productsError = action.payload || "Failed to fetch counseling products";
        });
        // Fetch Counseling Product By Slug
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCounselingProductBySlug"].pending, (state)=>{
            state.selectedProductLoading = true;
            state.selectedProductError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCounselingProductBySlug"].fulfilled, (state, action)=>{
            state.selectedProductLoading = false;
            state.selectedProduct = action.payload;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchCounselingProductBySlug"].rejected, (state, action)=>{
            state.selectedProductLoading = false;
            state.selectedProductError = action.payload || "Failed to fetch counseling product";
        });
    }
});
const { resetProducts, clearSelectedProduct } = counselingSlice.actions;
const __TURBOPACK__default__export__ = counselingSlice.reducer;
const selectCounselingProducts = (state)=>state.counseling.products;
const selectProductsLoading = (state)=>state.counseling.productsLoading;
const selectProductsError = (state)=>state.counseling.productsError;
const selectTotalPages = (state)=>state.counseling.totalPages;
const selectCurrentPage = (state)=>state.counseling.currentPage;
const selectTotal = (state)=>state.counseling.total;
const selectSelectedProduct = (state)=>state.counseling.selectedProduct;
const selectSelectedProductLoading = (state)=>state.counseling.selectedProductLoading;
const selectSelectedProductError = (state)=>state.counseling.selectedProductError;
}),
"[project]/src/store/coupon/couponThunk.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchAvailableCoupons",
    ()=>fetchAvailableCoupons,
    "validateCoupon",
    ()=>validateCoupon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/Axios.jsx [app-ssr] (ecmascript)");
;
;
const validateCoupon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("coupon/validate", async ({ code, productId }, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/coupons/validate", {
            code,
            productId
        });
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "Invalid coupon");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to validate coupon");
    }
});
const fetchAvailableCoupons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("coupon/fetchAvailable", async (productId, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/coupons?productId=${productId}&isActive=true`);
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "Failed to fetch coupons");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch available coupons");
    }
});
}),
"[project]/src/store/coupon/couponSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearCouponError",
    ()=>clearCouponError,
    "clearValidatedCoupon",
    ()=>clearValidatedCoupon,
    "default",
    ()=>__TURBOPACK__default__export__,
    "selectAvailableCoupons",
    ()=>selectAvailableCoupons,
    "selectCouponError",
    ()=>selectCouponError,
    "selectCouponLoading",
    ()=>selectCouponLoading,
    "selectValidatedCoupon",
    ()=>selectValidatedCoupon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/coupon/couponThunk.ts [app-ssr] (ecmascript)");
;
;
const initialState = {
    availableCoupons: [],
    validatedCoupon: null,
    loading: false,
    error: null
};
const couponSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "coupon",
    initialState,
    reducers: {
        clearValidatedCoupon: (state)=>{
            state.validatedCoupon = null;
            state.error = null;
        },
        clearCouponError: (state)=>{
            state.error = null;
        }
    },
    extraReducers: (builder)=>{
        // Validate Coupon
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["validateCoupon"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["validateCoupon"].fulfilled, (state, action)=>{
            state.loading = false;
            state.validatedCoupon = action.payload;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["validateCoupon"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
            state.validatedCoupon = null;
        });
        // Fetch Available Coupons
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchAvailableCoupons"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchAvailableCoupons"].fulfilled, (state, action)=>{
            state.loading = false;
            state.availableCoupons = action.payload;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchAvailableCoupons"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
    }
});
const { clearValidatedCoupon, clearCouponError } = couponSlice.actions;
const selectAvailableCoupons = (state)=>state.coupon.availableCoupons;
const selectValidatedCoupon = (state)=>state.coupon.validatedCoupon;
const selectCouponLoading = (state)=>state.coupon.loading;
const selectCouponError = (state)=>state.coupon.error;
const __TURBOPACK__default__export__ = couponSlice.reducer;
}),
"[project]/src/store/order/orderThunk.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createOrder",
    ()=>createOrder,
    "downloadInvoice",
    ()=>downloadInvoice,
    "fetchUserOrders",
    ()=>fetchUserOrders,
    "verifyPayment",
    ()=>verifyPayment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/Axios.jsx [app-ssr] (ecmascript)");
;
;
const createOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("order/create", async (orderData, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/payment/create-order", orderData);
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "Failed to create order");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to create order");
    }
});
const verifyPayment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("order/verifyPayment", async (paymentData, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/payment/verify", paymentData);
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "Payment verification failed");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Payment verification failed");
    }
});
const fetchUserOrders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("order/fetchUserOrders", async (_, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/student/orders");
        if (!response.data.success) {
            return rejectWithValue(response.data.message || "Failed to fetch orders");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch user orders");
    }
});
const downloadInvoice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("order/downloadInvoice", async (orderId, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/student/orders/${orderId}/invoice`, {
            responseType: "blob"
        });
        // Create download link
        const url = window.URL.createObjectURL(new Blob([
            response.data
        ]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", `invoice-${orderId}.pdf`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url);
        return {
            success: true
        };
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to download invoice");
    }
});
}),
"[project]/src/store/order/orderSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearCurrentOrder",
    ()=>clearCurrentOrder,
    "clearOrderError",
    ()=>clearOrderError,
    "default",
    ()=>__TURBOPACK__default__export__,
    "selectCurrentOrder",
    ()=>selectCurrentOrder,
    "selectOrderError",
    ()=>selectOrderError,
    "selectOrderLoading",
    ()=>selectOrderLoading,
    "selectPaymentError",
    ()=>selectPaymentError,
    "selectPaymentLoading",
    ()=>selectPaymentLoading,
    "selectUserOrders",
    ()=>selectUserOrders
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/order/orderThunk.ts [app-ssr] (ecmascript)");
;
;
const initialState = {
    currentOrder: null,
    userOrders: [],
    loading: false,
    error: null,
    paymentLoading: false,
    paymentError: null
};
const orderSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "order",
    initialState,
    reducers: {
        clearCurrentOrder: (state)=>{
            state.currentOrder = null;
            state.error = null;
        },
        clearOrderError: (state)=>{
            state.error = null;
            state.paymentError = null;
        }
    },
    extraReducers: (builder)=>{
        // Create Order
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createOrder"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createOrder"].fulfilled, (state, action)=>{
            state.loading = false;
            state.currentOrder = action.payload;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createOrder"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
        // Verify Payment
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["verifyPayment"].pending, (state)=>{
            state.paymentLoading = true;
            state.paymentError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["verifyPayment"].fulfilled, (state, action)=>{
            state.paymentLoading = false;
            state.currentOrder = action.payload;
            state.paymentError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["verifyPayment"].rejected, (state, action)=>{
            state.paymentLoading = false;
            state.paymentError = action.payload;
        });
        // Fetch User Orders
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserOrders"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserOrders"].fulfilled, (state, action)=>{
            state.loading = false;
            state.userOrders = action.payload;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserOrders"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
        // Download Invoice
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["downloadInvoice"].pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["downloadInvoice"].fulfilled, (state)=>{
            state.loading = false;
            state.error = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["downloadInvoice"].rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
    }
});
const { clearCurrentOrder, clearOrderError } = orderSlice.actions;
const selectCurrentOrder = (state)=>state.order.currentOrder;
const selectUserOrders = (state)=>state.order.userOrders;
const selectOrderLoading = (state)=>state.order.loading;
const selectOrderError = (state)=>state.order.error;
const selectPaymentLoading = (state)=>state.order.paymentLoading;
const selectPaymentError = (state)=>state.order.paymentError;
const __TURBOPACK__default__export__ = orderSlice.reducer;
}),
"[project]/src/store/exam/examThunk.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchExamById",
    ()=>fetchExamById,
    "fetchExams",
    ()=>fetchExams
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/Axios.jsx [app-ssr] (ecmascript)");
;
;
const fetchExams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("exam/fetchExams", async (params = {}, { rejectWithValue })=>{
    try {
        const { page = 1, limit = 10, isActive = true } = params;
        // Build query parameters
        const queryParams = new URLSearchParams({
            page: page.toString(),
            limit: limit.toString(),
            isActive: isActive.toString()
        });
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/exams?${queryParams.toString()}`);
        return {
            data: response.data.data,
            total: response.data.pagination.total,
            count: response.data.count,
            currentPage: page,
            totalPages: response.data.pagination.pages
        };
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch exams");
    }
});
const fetchExamById = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("exam/fetchExamById", async (id, { rejectWithValue })=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$Axios$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/exams/${id}`);
        if (!response.data.success) {
            return rejectWithValue("Exam not found");
        }
        return response.data.data;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch exam");
    }
});
}),
"[project]/src/store/exam/examSlice.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearSelectedExam",
    ()=>clearSelectedExam,
    "default",
    ()=>__TURBOPACK__default__export__,
    "resetExams",
    ()=>resetExams,
    "selectCurrentPage",
    ()=>selectCurrentPage,
    "selectExams",
    ()=>selectExams,
    "selectExamsError",
    ()=>selectExamsError,
    "selectExamsLoading",
    ()=>selectExamsLoading,
    "selectSelectedExam",
    ()=>selectSelectedExam,
    "selectSelectedExamError",
    ()=>selectSelectedExamError,
    "selectSelectedExamLoading",
    ()=>selectSelectedExamLoading,
    "selectTotal",
    ()=>selectTotal,
    "selectTotalPages",
    ()=>selectTotalPages
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/exam/examThunk.ts [app-ssr] (ecmascript)");
;
;
// ---------------------------
// Initial State
// ---------------------------
const initialState = {
    exams: [],
    totalPages: 0,
    currentPage: 1,
    total: 0,
    examsLoading: false,
    examsError: null,
    selectedExam: null,
    selectedExamLoading: false,
    selectedExamError: null
};
// ---------------------------
// Slice
// ---------------------------
const examSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "exam",
    initialState,
    reducers: {
        resetExams: (state)=>{
            state.exams = [];
            state.totalPages = 0;
            state.currentPage = 1;
            state.total = 0;
            state.examsError = null;
        },
        clearSelectedExam: (state)=>{
            state.selectedExam = null;
            state.selectedExamError = null;
        }
    },
    extraReducers: (builder)=>{
        // Fetch Exams
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchExams"].pending, (state)=>{
            state.examsLoading = true;
            state.examsError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchExams"].fulfilled, (state, action)=>{
            state.examsLoading = false;
            state.exams = action.payload.data;
            state.totalPages = action.payload.totalPages;
            state.currentPage = action.payload.currentPage;
            state.total = action.payload.total;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchExams"].rejected, (state, action)=>{
            state.examsLoading = false;
            state.examsError = action.payload || "Failed to fetch exams";
        });
        // Fetch Exam By ID
        builder.addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchExamById"].pending, (state)=>{
            state.selectedExamLoading = true;
            state.selectedExamError = null;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchExamById"].fulfilled, (state, action)=>{
            state.selectedExamLoading = false;
            state.selectedExam = action.payload;
        }).addCase(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchExamById"].rejected, (state, action)=>{
            state.selectedExamLoading = false;
            state.selectedExamError = action.payload || "Failed to fetch exam";
        });
    }
});
const { resetExams, clearSelectedExam } = examSlice.actions;
const __TURBOPACK__default__export__ = examSlice.reducer;
const selectExams = (state)=>state.exam.exams;
const selectExamsLoading = (state)=>state.exam.examsLoading;
const selectExamsError = (state)=>state.exam.examsError;
const selectTotalPages = (state)=>state.exam.totalPages;
const selectCurrentPage = (state)=>state.exam.currentPage;
const selectTotal = (state)=>state.exam.total;
const selectSelectedExam = (state)=>state.exam.selectedExam;
const selectSelectedExamLoading = (state)=>state.exam.selectedExamLoading;
const selectSelectedExamError = (state)=>state.exam.selectedExamError;
}),
"[project]/src/store/store.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "store",
    ()=>store
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/auth/authSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/counsellor/counsellorSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/college/collegeSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/counseling/counselingSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/coupon/couponSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/order/orderSlice.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/exam/examSlice.ts [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["configureStore"])({
    reducer: {
        auth: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
        counsellor: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counsellor$2f$counsellorSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
        college: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$college$2f$collegeSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
        counseling: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$counseling$2f$counselingSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
        coupon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$coupon$2f$couponSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
        order: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$order$2f$orderSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
        exam: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$exam$2f$examSlice$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    }
});
}),
"[project]/src/app/StoreProvider.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StoreProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/store.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
function StoreProvider({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Provider"], {
        store: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["store"],
        children: children
    }, void 0, false, {
        fileName: "[project]/src/app/StoreProvider.tsx",
        lineNumber: 10,
        columnNumber: 10
    }, this);
}
}),
"[project]/src/store/hooks.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAppDispatch",
    ()=>useAppDispatch,
    "useAppSelector",
    ()=>useAppSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
;
const useAppDispatch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"];
const useAppSelector = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"];
}),
"[project]/src/app/auth/UserInitializer.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>UserInitializer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$hooks$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/hooks.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/auth/authThunk.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
function UserInitializer() {
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$hooks$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    const getUser = async ()=>{
        const token = localStorage.getItem("token");
        if (token) {
            await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2f$authThunk$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchUserProfile"])()).unwrap();
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        getUser();
    }, [
        dispatch
    ]);
    return null; // nothing to render
}
}),
"[project]/src/components/loader/Loader.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const Loader = ({ manualLoading = false })=>{
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    setTimeout(()=>{
        setIsLoading(false);
    }, 1000);
    if (!isLoading && !manualLoading) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full w-full flex items-center justify-center fixed z-90 flex-col bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                src: "/logo.svg",
                height: 100,
                width: 200,
                alt: ""
            }, void 0, false, {
                fileName: "[project]/src/components/loader/Loader.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold",
                children: "We Won Acedemy"
            }, void 0, false, {
                fileName: "[project]/src/components/loader/Loader.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                className: "animate-spin mt-4 w-8 h-8"
            }, void 0, false, {
                fileName: "[project]/src/components/loader/Loader.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/loader/Loader.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Loader;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__caa6fd70._.js.map